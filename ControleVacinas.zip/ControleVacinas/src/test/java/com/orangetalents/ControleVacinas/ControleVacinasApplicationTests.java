package com.orangetalents.ControleVacinas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ControleVacinasApplicationTests {

	@Test
	void contextLoads() {
	}

}
